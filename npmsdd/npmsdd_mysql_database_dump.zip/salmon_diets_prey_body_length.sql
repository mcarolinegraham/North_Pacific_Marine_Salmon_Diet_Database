-- MySQL dump 10.13  Distrib 8.0.17, for macos10.14 (x86_64)
--
-- Host: localhost    Database: salmon_diets
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `prey_body_length`
--

DROP TABLE IF EXISTS `prey_body_length`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prey_body_length` (
  `prey_id` int(10) unsigned NOT NULL,
  `value` decimal(13,3) DEFAULT NULL,
  `mean` decimal(13,3) DEFAULT NULL,
  `error` decimal(13,3) DEFAULT NULL,
  `min` decimal(13,3) DEFAULT NULL,
  `max` decimal(13,3) DEFAULT NULL,
  `units` varchar(45) NOT NULL DEFAULT 'unspecified',
  `prey_bio_notes` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`prey_id`,`units`),
  CONSTRAINT `prey_id5` FOREIGN KEY (`prey_id`) REFERENCES `prey` (`prey_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prey_body_length`
--

LOCK TABLES `prey_body_length` WRITE;
/*!40000 ALTER TABLE `prey_body_length` DISABLE KEYS */;
INSERT INTO `prey_body_length` VALUES (1,NULL,NULL,NULL,4.000,6.000,'millimeters',NULL),(2,NULL,NULL,NULL,8.000,11.000,'millimeters',NULL),(3,NULL,NULL,NULL,6.000,7.000,'millimeters',NULL),(4,NULL,NULL,NULL,10.000,11.000,'millimeters',NULL),(171,NULL,0.890,0.010,NULL,NULL,'millimeters',NULL),(172,NULL,0.740,0.020,NULL,NULL,'millimeters',NULL),(173,NULL,2.670,0.030,NULL,NULL,'millimeters',NULL),(174,NULL,1.010,0.010,NULL,NULL,'millimeters',NULL),(175,NULL,1.650,0.020,NULL,NULL,'millimeters',NULL),(176,NULL,1.290,0.030,NULL,NULL,'millimeters',NULL),(177,NULL,1.450,0.070,NULL,NULL,'millimeters',NULL),(178,NULL,2.870,0.080,NULL,NULL,'millimeters',NULL),(179,NULL,3.090,0.080,NULL,NULL,'millimeters',NULL),(180,NULL,4.730,0.130,NULL,NULL,'millimeters',NULL),(181,NULL,0.380,0.030,NULL,NULL,'millimeters',NULL),(193,NULL,NULL,NULL,18.000,24.000,'millimeters',NULL),(194,NULL,NULL,NULL,14.000,26.000,'millimeters',NULL),(195,NULL,NULL,NULL,16.000,20.000,'millimeters',NULL),(196,NULL,NULL,NULL,22.000,26.000,'millimeters',NULL),(197,NULL,NULL,NULL,6.000,8.000,'millimeters',NULL),(198,NULL,NULL,NULL,6.000,7.000,'millimeters',NULL),(199,NULL,NULL,NULL,2.500,4.000,'millimeters',NULL),(200,NULL,NULL,NULL,1.800,2.000,'millimeters',NULL),(201,NULL,NULL,NULL,2.500,3.000,'millimeters',NULL),(202,NULL,NULL,NULL,2.500,3.000,'millimeters',NULL),(203,NULL,NULL,NULL,4.000,6.000,'millimeters',NULL),(204,NULL,NULL,NULL,1.500,2.300,'millimeters',NULL),(205,NULL,NULL,NULL,1.800,3.000,'millimeters',NULL),(206,NULL,NULL,NULL,2.400,9.000,'millimeters',NULL),(207,NULL,NULL,NULL,4.000,9.000,'millimeters',NULL),(208,NULL,NULL,NULL,6.000,12.000,'millimeters',NULL),(209,NULL,NULL,NULL,17.000,28.000,'millimeters',NULL),(210,NULL,NULL,NULL,2.000,3.000,'millimeters',NULL),(211,NULL,NULL,NULL,2.000,4.000,'millimeters',NULL),(212,NULL,NULL,NULL,2.000,4.000,'millimeters',NULL),(213,NULL,NULL,NULL,50.000,60.000,'millimeters',NULL),(214,NULL,NULL,NULL,4.000,5.000,'millimeters',NULL),(215,NULL,NULL,NULL,10.000,18.000,'millimeters',NULL),(216,NULL,NULL,NULL,3.000,4.800,'millimeters',NULL),(217,NULL,NULL,NULL,7.000,48.000,'millimeters',NULL),(218,NULL,NULL,NULL,3.000,5.000,'millimeters',NULL),(219,NULL,NULL,NULL,18.000,24.000,'millimeters',NULL),(220,NULL,NULL,NULL,14.000,26.000,'millimeters',NULL),(221,NULL,NULL,NULL,16.000,18.000,'millimeters',NULL),(222,NULL,NULL,NULL,22.000,26.000,'millimeters',NULL),(223,NULL,NULL,NULL,6.000,8.000,'millimeters',NULL),(224,NULL,NULL,NULL,6.000,8.000,'millimeters',NULL),(225,NULL,NULL,NULL,2.200,4.000,'millimeters',NULL),(226,NULL,NULL,NULL,2.500,3.200,'millimeters',NULL),(227,NULL,NULL,NULL,2.500,3.200,'millimeters',NULL),(228,NULL,NULL,NULL,5.000,6.500,'millimeters',NULL),(229,NULL,NULL,NULL,1.500,2.300,'millimeters',NULL),(230,NULL,NULL,NULL,1.800,3.000,'millimeters',NULL),(231,NULL,NULL,NULL,2.400,9.000,'millimeters',NULL),(232,NULL,NULL,NULL,4.000,9.000,'millimeters',NULL),(233,NULL,NULL,NULL,6.000,10.000,'millimeters',NULL),(234,NULL,NULL,NULL,17.000,28.000,'millimeters',NULL),(235,NULL,NULL,NULL,2.000,3.000,'millimeters',NULL),(236,NULL,NULL,NULL,2.000,4.000,'millimeters',NULL),(237,NULL,NULL,NULL,7.000,48.000,'millimeters',NULL),(238,NULL,NULL,NULL,10.000,18.000,'millimeters',NULL);
/*!40000 ALTER TABLE `prey_body_length` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-26 10:54:50
