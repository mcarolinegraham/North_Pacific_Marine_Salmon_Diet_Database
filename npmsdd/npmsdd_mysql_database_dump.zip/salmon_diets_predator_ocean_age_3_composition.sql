-- MySQL dump 10.13  Distrib 8.0.17, for macos10.14 (x86_64)
--
-- Host: localhost    Database: salmon_diets
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `predator_ocean_age_3_composition`
--

DROP TABLE IF EXISTS `predator_ocean_age_3_composition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `predator_ocean_age_3_composition` (
  `predator_id` int(10) unsigned NOT NULL,
  `value` decimal(13,3) DEFAULT NULL,
  `mean` decimal(13,3) DEFAULT NULL,
  `error` decimal(13,3) DEFAULT NULL,
  `min` decimal(13,3) DEFAULT NULL,
  `max` decimal(13,3) DEFAULT NULL,
  `units` varchar(45) NOT NULL DEFAULT 'unspecified',
  `predator_bio_notes` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`predator_id`,`units`),
  CONSTRAINT `predid121` FOREIGN KEY (`predator_id`) REFERENCES `predator` (`predator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `predator_ocean_age_3_composition`
--

LOCK TABLES `predator_ocean_age_3_composition` WRITE;
/*!40000 ALTER TABLE `predator_ocean_age_3_composition` DISABLE KEYS */;
INSERT INTO `predator_ocean_age_3_composition` VALUES (6476,6.000,NULL,NULL,NULL,NULL,'percent',NULL),(6477,61.000,NULL,NULL,NULL,NULL,'percent',NULL),(6497,4.000,NULL,NULL,NULL,NULL,'percent',NULL),(6498,4.000,NULL,NULL,NULL,NULL,'percent',NULL),(6499,12.000,NULL,NULL,NULL,NULL,'percent',NULL),(6500,19.000,NULL,NULL,NULL,NULL,'percent',NULL),(6501,0.000,NULL,NULL,NULL,NULL,'percent',NULL),(6502,0.000,NULL,NULL,NULL,NULL,'percent',NULL),(6503,0.000,NULL,NULL,NULL,NULL,'percent',NULL),(6504,10.000,NULL,NULL,NULL,NULL,'percent',NULL),(6505,67.000,NULL,NULL,NULL,NULL,'percent',NULL),(6506,30.000,NULL,NULL,NULL,NULL,'percent',NULL),(6507,64.000,NULL,NULL,NULL,NULL,'percent',NULL),(6508,40.000,NULL,NULL,NULL,NULL,'percent',NULL),(6509,67.000,NULL,NULL,NULL,NULL,'percent',NULL),(6510,56.000,NULL,NULL,NULL,NULL,'percent',NULL),(6511,78.000,NULL,NULL,NULL,NULL,'percent',NULL),(6512,66.000,NULL,NULL,NULL,NULL,'percent',NULL);
/*!40000 ALTER TABLE `predator_ocean_age_3_composition` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-26 10:54:54
