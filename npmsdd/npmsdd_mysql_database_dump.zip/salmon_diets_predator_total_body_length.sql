-- MySQL dump 10.13  Distrib 8.0.17, for macos10.14 (x86_64)
--
-- Host: localhost    Database: salmon_diets
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `predator_total_body_length`
--

DROP TABLE IF EXISTS `predator_total_body_length`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `predator_total_body_length` (
  `predator_id` int(10) unsigned NOT NULL,
  `value` decimal(13,3) DEFAULT NULL,
  `mean` decimal(13,3) DEFAULT NULL,
  `error` decimal(13,3) DEFAULT NULL,
  `min` decimal(13,3) DEFAULT NULL,
  `max` decimal(13,3) DEFAULT NULL,
  `units` varchar(45) NOT NULL DEFAULT 'unspecified',
  `predator_bio_notes` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`predator_id`,`units`),
  CONSTRAINT `predid126` FOREIGN KEY (`predator_id`) REFERENCES `predator` (`predator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `predator_total_body_length`
--

LOCK TABLES `predator_total_body_length` WRITE;
/*!40000 ALTER TABLE `predator_total_body_length` DISABLE KEYS */;
INSERT INTO `predator_total_body_length` VALUES (5863,NULL,27.700,NULL,NULL,NULL,'centimeters',NULL),(5864,NULL,28.000,NULL,NULL,NULL,'centimeters',NULL),(5865,NULL,28.700,NULL,NULL,NULL,'centimeters',NULL),(5866,NULL,24.400,NULL,NULL,NULL,'centimeters',NULL),(5867,NULL,23.700,NULL,NULL,NULL,'centimeters',NULL),(5868,NULL,24.700,NULL,NULL,NULL,'centimeters',NULL),(7090,NULL,35.000,NULL,30.000,39.000,'millimeters',NULL),(7091,NULL,58.000,NULL,44.000,80.000,'millimeters',NULL),(7092,NULL,71.000,NULL,64.000,83.000,'millimeters',NULL),(7093,NULL,108.000,NULL,93.000,123.000,'millimeters',NULL),(7094,NULL,153.000,NULL,127.000,190.000,'millimeters',NULL),(7095,NULL,247.000,NULL,192.000,280.000,'millimeters',NULL),(7096,NULL,42.000,NULL,NULL,NULL,'millimeters',NULL),(7097,NULL,96.000,NULL,NULL,NULL,'millimeters',NULL),(7098,NULL,223.000,NULL,NULL,NULL,'millimeters',NULL),(7099,NULL,34.000,NULL,NULL,NULL,'millimeters',NULL),(7100,NULL,NULL,NULL,32.000,33.000,'millimeters',NULL),(7101,NULL,NULL,NULL,50.000,68.000,'millimeters',NULL),(7102,NULL,80.000,NULL,67.000,92.000,'millimeters',NULL),(7103,NULL,33.000,NULL,29.000,39.000,'millimeters',NULL),(7104,NULL,45.000,NULL,30.000,56.000,'millimeters',NULL),(7105,NULL,69.000,NULL,38.000,88.000,'millimeters',NULL),(7106,NULL,82.000,NULL,60.000,112.000,'millimeters',NULL);
/*!40000 ALTER TABLE `predator_total_body_length` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-25 16:53:47
