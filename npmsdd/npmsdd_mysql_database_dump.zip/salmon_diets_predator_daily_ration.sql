-- MySQL dump 10.13  Distrib 8.0.17, for macos10.14 (x86_64)
--
-- Host: localhost    Database: salmon_diets
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `predator_daily_ration`
--

DROP TABLE IF EXISTS `predator_daily_ration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `predator_daily_ration` (
  `predator_id` int(10) unsigned NOT NULL,
  `value` decimal(13,3) DEFAULT NULL,
  `mean` decimal(13,3) DEFAULT NULL,
  `error` decimal(13,3) DEFAULT NULL,
  `min` decimal(13,3) DEFAULT NULL,
  `max` decimal(13,3) DEFAULT NULL,
  `units` varchar(45) NOT NULL DEFAULT 'unspecified',
  `predator_bio_notes` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`predator_id`,`units`),
  CONSTRAINT `predid106` FOREIGN KEY (`predator_id`) REFERENCES `predator` (`predator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `predator_daily_ration`
--

LOCK TABLES `predator_daily_ration` WRITE;
/*!40000 ALTER TABLE `predator_daily_ration` DISABLE KEYS */;
INSERT INTO `predator_daily_ration` VALUES (394,NULL,3.900,NULL,NULL,NULL,'percent','weight of stomach contents/body weight'),(395,NULL,3.800,NULL,NULL,NULL,'percent','weight of stomach contents/body weight'),(407,NULL,4.100,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(408,NULL,2.500,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(409,NULL,3.200,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(410,NULL,2.900,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(411,NULL,5.400,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(412,NULL,3.100,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(413,NULL,4.000,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(414,NULL,2.100,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(416,NULL,2.200,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(417,NULL,2.400,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(419,NULL,3.100,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(420,NULL,4.200,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(423,NULL,3.800,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(424,NULL,2.900,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(425,NULL,2.200,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(427,NULL,4.500,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(1425,NULL,2.100,0.300,NULL,NULL,'percent','percent of body mass'),(1430,NULL,1.400,0.100,NULL,NULL,'percent','percent of body mass'),(1431,NULL,1.700,0.200,NULL,NULL,'percent','percent of body mass'),(1432,NULL,1.200,0.100,NULL,NULL,'percent','percent of body mass'),(1433,NULL,1.000,0.100,NULL,NULL,'percent','percent of body mass'),(1434,NULL,1.600,0.200,NULL,NULL,'percent','percent of body mass'),(1435,NULL,1.300,0.100,NULL,NULL,'percent','percent of body mass'),(1436,NULL,1.300,0.100,NULL,NULL,'percent','percent of body mass'),(1437,NULL,1.200,0.100,NULL,NULL,'percent','percent of body mass'),(1438,NULL,1.900,0.200,NULL,NULL,'percent','percent of body mass'),(1439,NULL,0.500,0.200,NULL,NULL,'percent','percent of body mass'),(1440,NULL,1.300,0.400,NULL,NULL,'percent','percent of body mass'),(1441,NULL,0.900,0.200,NULL,NULL,'percent','percent of body mass'),(1442,NULL,1.500,0.200,NULL,NULL,'percent','percent of body mass'),(1443,NULL,2.100,0.400,NULL,NULL,'percent','percent of body mass'),(1444,NULL,1.000,0.200,NULL,NULL,'percent','percent of body mass'),(1445,NULL,1.800,0.600,NULL,NULL,'percent','percent of body mass'),(6230,NULL,2.100,NULL,NULL,NULL,'percent','percent of body mass'),(6231,NULL,2.100,NULL,NULL,NULL,'percent','percent of body mass'),(6232,NULL,3.000,NULL,NULL,NULL,'percent','percent of body mass'),(6233,NULL,3.600,NULL,NULL,NULL,'percent','percent of body mass'),(6234,NULL,1.200,NULL,NULL,NULL,'percent','percent of body mass'),(6235,NULL,1.200,NULL,NULL,NULL,'percent','percent of body mass'),(6236,NULL,1.200,NULL,NULL,NULL,'percent','percent of body mass'),(6237,NULL,0.300,NULL,NULL,NULL,'percent','percent of body mass'),(6239,NULL,2.200,NULL,NULL,NULL,'percent','values are reported as percent of body weight'),(6552,NULL,1.300,0.300,NULL,NULL,'percent','percent of body mass'),(6553,NULL,1.400,0.100,NULL,NULL,'percent','percent of body mass'),(6554,NULL,1.300,0.300,NULL,NULL,'percent','percent of body mass'),(6555,NULL,1.800,0.200,NULL,NULL,'percent','percent of body mass'),(6676,NULL,0.980,NULL,0.000,11.500,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6677,NULL,0.450,NULL,0.040,4.940,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6678,NULL,0.130,NULL,0.000,13.570,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6679,NULL,0.130,NULL,0.000,1.200,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6680,NULL,0.100,NULL,0.000,5.400,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6681,NULL,0.070,NULL,0.000,5.350,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6682,NULL,0.000,NULL,0.000,5.910,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6683,NULL,0.350,NULL,0.350,0.350,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6684,NULL,0.300,NULL,0.000,17.660,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6685,NULL,0.290,NULL,0.000,12.160,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6686,NULL,0.130,NULL,0.000,9.440,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6687,NULL,0.100,NULL,0.000,1.980,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6688,NULL,0.040,NULL,0.000,5.090,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6689,NULL,2.240,NULL,0.990,6.440,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6690,NULL,0.310,NULL,0.000,4.180,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6691,NULL,0.300,NULL,0.260,0.450,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6692,NULL,0.180,NULL,0.000,5.800,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6693,NULL,0.050,NULL,0.000,5.210,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6694,NULL,0.000,NULL,0.000,0.000,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6695,NULL,0.230,NULL,0.000,6.220,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6696,NULL,0.180,NULL,0.000,9.700,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6697,NULL,0.130,NULL,0.000,5.630,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6698,NULL,0.070,NULL,0.000,3.050,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6699,NULL,0.030,NULL,0.000,5.610,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6700,NULL,0.100,NULL,0.000,9.870,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6701,NULL,0.240,NULL,0.000,9.170,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6702,NULL,0.250,NULL,0.000,13.570,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6703,NULL,0.150,NULL,0.000,11.200,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6704,NULL,0.180,NULL,0.000,12.230,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6705,NULL,0.190,NULL,0.000,17.660,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6706,NULL,0.110,NULL,0.000,10.770,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6707,NULL,0.130,NULL,0.000,12.160,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6708,NULL,0.380,NULL,0.000,6.740,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6709,NULL,0.090,NULL,0.000,7.520,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6710,NULL,0.210,NULL,0.000,6.440,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6711,NULL,0.370,NULL,0.000,5.210,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6712,NULL,0.090,NULL,0.000,6.270,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6713,NULL,0.090,NULL,0.000,5.630,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6714,NULL,0.140,NULL,0.000,9.700,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(6715,NULL,0.060,NULL,0.000,13.560,'unspecified','stomach dry weight (g)/estimated fish wet weight (kg)'),(7111,NULL,5.000,NULL,NULL,NULL,'unspecified','weight of stomach contents/body weight'),(7112,NULL,10.000,NULL,NULL,NULL,'unspecified','weight of stomach contents/body weight'),(7113,NULL,7.000,NULL,NULL,NULL,'unspecified','weight of stomach contents/body weight'),(7114,NULL,5.000,NULL,NULL,NULL,'unspecified','weight of stomach contents/body weight'),(7115,NULL,4.500,NULL,NULL,NULL,'unspecified','weight of stomach contents/body weight'),(7116,NULL,3.000,NULL,NULL,NULL,'unspecified','weight of stomach contents/body weight'),(7117,NULL,3.500,NULL,NULL,NULL,'unspecified','weight of stomach contents/body weight'),(7118,NULL,4.000,NULL,NULL,NULL,'unspecified','weight of stomach contents/body weight'),(7119,NULL,5.000,NULL,NULL,NULL,'unspecified','weight of stomach contents/body weight');
/*!40000 ALTER TABLE `predator_daily_ration` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-14 16:06:47
