-- MySQL dump 10.13  Distrib 8.0.17, for macos10.14 (x86_64)
--
-- Host: localhost    Database: salmon_diets
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `prey_size_index`
--

DROP TABLE IF EXISTS `prey_size_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prey_size_index` (
  `prey_id` int(10) unsigned NOT NULL,
  `value` decimal(13,3) DEFAULT NULL,
  `mean` decimal(13,3) DEFAULT NULL,
  `error` decimal(13,3) DEFAULT NULL,
  `min` decimal(13,3) DEFAULT NULL,
  `max` decimal(13,3) DEFAULT NULL,
  `units` varchar(45) NOT NULL DEFAULT 'unspecified',
  `prey_bio_notes` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`prey_id`,`units`),
  CONSTRAINT `preyid103` FOREIGN KEY (`prey_id`) REFERENCES `prey` (`prey_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prey_size_index`
--

LOCK TABLES `prey_size_index` WRITE;
/*!40000 ALTER TABLE `prey_size_index` DISABLE KEYS */;
INSERT INTO `prey_size_index` VALUES (182,NULL,0.150,0.010,NULL,NULL,'unspecified','SI = pi(W/2)^2 *L. collected from zooplankton sampling station, not from inside salmon guts'),(183,NULL,0.150,0.010,NULL,NULL,'unspecified','SI = pi(W/2)^2 *L. collected from zooplankton sampling station, not from inside salmon guts'),(184,NULL,1.200,0.060,NULL,NULL,'unspecified','SI = pi(W/2)^2 *L. collected from zooplankton sampling station, not from inside salmon guts'),(185,NULL,0.080,0.000,NULL,NULL,'unspecified','SI = pi(W/2)^2 *L. collected from zooplankton sampling station, not from inside salmon guts'),(186,NULL,0.240,0.010,NULL,NULL,'unspecified','SI = pi(W/2)^2 *L. collected from zooplankton sampling station, not from inside salmon guts'),(187,NULL,0.070,0.000,NULL,NULL,'unspecified','SI = pi(W/2)^2 *L. collected from zooplankton sampling station, not from inside salmon guts'),(188,NULL,0.230,0.010,NULL,NULL,'unspecified','SI = pi(W/2)^2 *L. collected from zooplankton sampling station, not from inside salmon guts'),(189,NULL,1.220,0.100,NULL,NULL,'unspecified','SI = pi(W/2)^2 *L. collected from zooplankton sampling station, not from inside salmon guts'),(190,NULL,0.350,0.030,NULL,NULL,'unspecified','SI = pi(W/2)^2 *L. collected from zooplankton sampling station, not from inside salmon guts'),(191,NULL,1.020,0.060,NULL,NULL,'unspecified','SI = pi(W/2)^2 *L. collected from zooplankton sampling station, not from inside salmon guts'),(192,NULL,0.100,0.030,NULL,NULL,'unspecified','SI = pi(W/2)^2 *L. collected from zooplankton sampling station, not from inside salmon guts');
/*!40000 ALTER TABLE `prey_size_index` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-26 10:54:49
